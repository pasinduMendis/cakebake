import React from 'react'
import './UpperNotificationBar.css';

function UpperNotificationBar() {
  return (
    <div className='UpperNotificationBar'>Deliver within selected areas of western province</div>
  )
}

export default UpperNotificationBar