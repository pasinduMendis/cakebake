const express = require('express')
const orderRoutes = express.Router()
const Order = require('../models/orderModel')
const jwt=require("jsonwebtoken")
const Customer = require("../models/customerModel");

const userVerify=async (token)=>{
    try {
        const decoded = jwt.verify(
          token,
          process.env.JWT_SECRET
        )
        console.log(decoded.id)
        body=decoded.id
        if (!decoded) {
          return false;
        }else{
            const idVrify=await Customer.findOne({customer_id:decoded.id}).catch((err) => {
                console.log(err);
                return false;
              });
              if(idVrify){
                return true;
              }
              return false;
        }
      } catch (error) {
        return false;
      }
}

orderRoutes.post('/add', async (req, res) => {
    //need to add admin verification
    if(!req.query.token){
        res.send("user token must needed!")
        return
    }
    const isUserTest=await userVerify(req.query.token)
    console.log(isUserTest)
    if(!isUserTest){
        res.send("failed!")
        return;
    }
  const data = new Order(req.body)
  await data
    .save()
    .then(() => {
      res.send('successfully added')
      return
    })
    .catch((err) => res.send('failed'))
})

module.exports = orderRoutes;