const mongoose = require("mongoose");

const orderSchema = mongoose.Schema({
  id: mongoose.Schema.Types.ObjectId,
  order:{type:[],required: true},
  customer:{type:String,required: true},
  shipping_data:{type:{},required: true}
});

module.exports = mongoose.model("Order", orderSchema);
