module.exports = {
  DB: 'mongodb+srv://BakedDelights:Baked123@cluster0.aubg6b0.mongodb.net/?retryWrites=true&w=majority',
}
